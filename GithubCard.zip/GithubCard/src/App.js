import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Gitform from './Gitform';


class App extends Component {
  render() {
    return (
      <div className="App">
        <div className="App-header">
          <img src={logo} title='-made by Anupam ' className="App-logo" alt="logo" />

          <h2 title='-made by Anupam '>Welcome to Github Card Search</h2>


        </div>
        <Gitform />

      </div>
    );
  }
}

export default App;
