import React, { Component } from 'react';

class Cards extends Component {


todelete(){

    this.props.del(this.props.qwe);
}


  constructor(props){
    super(props);
    this.todelete=this.todelete.bind(this);

  }




  render(){


    return(

      <div className='card'>
        <br />
        <img src = {this.props.avat} id='prof' alt="img not found" width='200' />
        <h4>Name:<mark>{this.props.name}</mark></h4>
        <h5>Location:<mark>{this.props.loc}</mark></h5>
        <h6>Followers:<mark>{this.props.fol}</mark></h6>
        <a href='#' id="del" onClick={this.todelete}>x</a>

      </div>

    );

}
}

export default Cards;
