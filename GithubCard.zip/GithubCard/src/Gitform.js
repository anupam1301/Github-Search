import React, { Component } from 'react';
import $ from 'jquery';
import Cards from './Cards';
import up from './up.png';
import './App.css';

const API='https://api.github.com/users/';

class Gitform extends Component {

  sortname(){

    if(this.state.logins.length!==0){
    var hid=document.getElementById('img');
    hid.classList.remove('hide');}

        if(this.state.p===0){

          var aro=document.getElementById('img');
          aro.classList.add('down');

            function compare(a,b) {
            if (a.name < b.name)
            return -1;
            if (a.name > b.name)
            return 1;
          return 0;
        }

        var logins=this.state.logins.sort(compare);
        this.setState({logins: logins,p: 1});

      }

      if(this.state.p===1){

        var aro=document.getElementById('img');
        aro.classList.remove('down');

          function compare(a,b) {
          if (a.name < b.name )
          return 1;
          if (a.name > b.name )
          return -1;
        return 0;
      }

      var logins=this.state.logins.sort(compare);
      this.setState({logins: logins, p: 0});

    }
    }

  sortloc(){

    if(this.state.logins.length!==0){
    var hid=document.getElementById('img2');
    hid.classList.remove('hide');}

    if(this.state.p===0){

      var aro=document.getElementById('img2');
      aro.classList.add('down');

        function compare(a,b) {
        if (a.location < b.location)
        return -1;
        if (a.location > b.location)
        return 1;
      return 0;
    }

    var logins=this.state.logins.sort(compare);
    this.setState({logins: logins,p: 1});

  }

  if(this.state.p===1){

    var aro=document.getElementById('img2');
    aro.classList.remove('down');

      function compare(a,b) {
      if (a.location < b.location )
      return 1;
      if (a.location > b.location )
      return -1;
    return 0;
  }

  var logins=this.state.logins.sort(compare);
  this.setState({logins: logins, p: 0});

}
      }

  sortfol(){

    if(this.state.logins.length!==0){
    var hid=document.getElementById('img3');
    hid.classList.remove('hide');}

    if(this.state.p===0){

      var aro=document.getElementById('img3');
      aro.classList.add('down');

        function compare(a,b) {
        if (a.followers < b.followers)
        return -1;
        if (a.followers > b.followers)
        return 1;
      return 0;
    }

    var logins=this.state.logins.sort(compare);
    this.setState({logins: logins,p: 1});

  }

  if(this.state.p===1){

    var aro=document.getElementById('img3');
    aro.classList.remove('down');

      function compare(a,b) {
      if (a.followers < b.followers )
      return 1;
      if (a.followers > b.followers )
      return -1;
    return 0;
  }

  var logins=this.state.logins.sort(compare);
  this.setState({logins: logins, p: 0});

}
      }

    handleDelete(itemId){
    //e.preventDefault();
      var newarr= this.state.logins;
      var i=itemId;

      newarr.splice(i, 1);
      this.setState({logins: newarr});

  }


  submitForm(e){

    e.preventDefault();
    var dis= this;

    let typo=  this.refs.login.value;
    let finalurl=`${API}${typo}`;

    $.get(finalurl, function(data) {

      for(var i=0;i<dis.state.logins.length;i++){
          if(dis.state.logins[i].login === data.login){var flag=1;}}

        if(flag !== 1){
      dis.setState({ logins: dis.state.logins.concat(data) });}


      var lout=document.getElementById('cd');
      lout.classList.remove('hide');
      dis.refs.login.value='';



    })
    .fail(function() {
    /*  var lout=document.getElementById('cd');
      lout.classList.add('hide');*/

      dis.refs.login.value='';
      alert("Not Found");
  });


  }




  constructor(props){
    super(props);

    this.state={
      logins: [],
      p: 0

    }

    this.submitForm=this.submitForm.bind(this);
    this.handleDelete=this.handleDelete.bind(this);
    this.sortname=this.sortname.bind(this);
    this.sortloc=this.sortloc.bind(this);
    this.sortfol=this.sortfol.bind(this);
  }
  render(){


    var arr= this.state.logins.map((login, i) => {
      return <Cards del={this.handleDelete}  name={login.name} loc={login.location} fol={login.followers} avat={login.avatar_url} key={i} qwe={i} />
      });

    return(
      <div>
        <form onSubmit={this.submitForm}>
          <div><br />
            <input id='ph' type='text' placeholder="Enter the Github Login" ref="login" />
            <input className="feedback-button" type="submit" value="Submit" />


          </div>
        </form>
        <div id="sort" className={this.state.logins.length<2 ? 'hide' : ''}>
          <h4>Sort By:&nbsp;&nbsp;
          <a href='#'onClick={this.sortname} name="name" ref="sort">Name&nbsp;<img className='down hide' id='img' src={up} width='12px' height='12px'/></a>&nbsp;&nbsp;&nbsp;&nbsp;
          <a href='#'onClick={this.sortloc} name="location" ref="sort">Location&nbsp;<img className='down hide' id='img2' src={up} width='12px' height='12px'/></a>&nbsp;&nbsp;&nbsp;&nbsp;
          <a href='#'onClick={this.sortfol} name="followers" ref="sort">Followers&nbsp;<img className='down hide' id='img3' src={up} width='12px' height='12px'/></a>
          </h4>
        </div>
        <div  id="cd" className='hide'>

            {arr}


        </div>
      </div>
    );
  }
}

export default Gitform;
